# main_controller.py
from controller import Robot
from python_controller import BioloidRobot
from python_controller import FRONT_LEFT_1, FRONT_RIGHT_1, FRONT_LEFT_2, FRONT_RIGHT_2, FRONT_LEFT_3, FRONT_RIGHT_3
from python_controller import BACK_LEFT_1, BACK_RIGHT_1, BACK_LEFT_2, BACK_RIGHT_2, BACK_LEFT_3, BACK_RIGHT_3
from python_controller import NECK_1, NECK_2, HEAD, PELVIS
from balance import BalanceController
from sensor_tuning import SensorProcessor
from unsticking import UnstickingController
from maze_navigation import MazeNavigator
from q_learning import QLearningAgent
import time

current_state = ""
action = ""

class MainController:
    def __init__(self):
        # Initialize the robot
        print("Initializing robot controller...")
        self.webots_robot = Robot()
        self.robot = BioloidRobot(self.webots_robot)
        
        # Define gait setup
        self.GAIT_SETUP = [
            [FRONT_LEFT_1, FRONT_LEFT_3],
            [FRONT_RIGHT_1, FRONT_RIGHT_3],
            [BACK_RIGHT_1, BACK_RIGHT_3],
            [BACK_LEFT_1, BACK_LEFT_3]
        ]
        
        # Initialize modules
        print("Setting up sensor processor...")
        self.sensor_processor = SensorProcessor(self.robot)
        
        print("Setting up balance controller...")
        self.balance_controller = BalanceController(self.robot)
        
        print("Setting up unsticking controller...")
        self.unsticking_controller = UnstickingController(self.robot, self.sensor_processor)
        
        print("Setting up maze navigator...")
        self.maze_navigator = MazeNavigator(self.robot, self.sensor_processor)
        
        print("Setting up Q-learning agent...")
        self.q_learning_agent = QLearningAgent(self.maze_navigator.grid_size)
        
        # Episode tracking
        self.episode_count = 0
        self.step_count = 0
        self.steps_per_episode = 50
        self.total_reward = 0

        self.is_goal_reached = False
        self.is_episode_end = False
        
        # Load Q-table if available
        self.q_learning_agent.load_q_table()
        
        # Setup robot
        print("Initializing robot...")
        self.robot.init_camera()
        
        # Calibrate IMU
        print("Calibrating IMU...")
        self.balance_controller.calibrate()
        
        # Set robot to standing position
        self.robot.standing()

        #global current_state
        #current_state = 0
        
        print("Robot controller initialization complete.")
    
    def run_episode(self):
        """Run a single episode."""
        self.episode_count += 1
        self.step_count = 0
        global total_reward
        total_reward = 0
        
        print(">>>> Starting Episode {self.episode_count} <<<<")
        
        # Get initial state
        global current_state
        current_state = self.maze_navigator.get_current_grid_position()
        if not current_state:
            print("Error: Unable to get current position.")
            return
        
        print(f"Initial position: Grid {current_state}")
        
        # Reset robot to standing position
        self.robot.standing()
        
        # Run steps until episode ends
        #global is_episode_end
        self.is_episode_end = False
        #global is_goal_reached
        #is_goal_reached = False
        while not self.is_episode_end:
        #if(not is_episode_end):
            #print("CHECK IF GOAL REACHED - VAL: " + str(self.is_goal_reached) )
            if self.is_goal_reached:
                print(">>>> GOAL REACHED, TERMINATING... <<<<")
                break #break loop as goal has been reached. This shouldn't be reached.

            #Increment step count
            self.step_count += 1
            if self.step_count > self.steps_per_episode:
                print("Step overrun detected, breaking loop...")
                #continue
                break
            
            # Check balance
            if self.balance_controller.is_falling():
                print("MAINCONT: Robot is losing balance. Applying correction...")
                self.balance_controller.apply_balance_correction()
                
                # If still falling, end episode
                if self.balance_controller.is_falling():
                    print("MAINCONT: Robot is falling. Ending episode.")
                    reward = self.maze_navigator.calculate_reward(is_fall=True)
                    self.total_reward += reward
                    self.is_episode_end = True
                    print("MAINCONT: Breaking loop here...")
                    break #break loop here to allow balance correction to work?
                    #return
                    #continue
            
            # Check for collisions
            collisions = self.sensor_processor.detect_collisions()

            
            # Choose action based on current state
            #print("HERE - CHOOSE ACTION CALL")
            global action
            action = self.q_learning_agent.choose_action(current_state)
            action_names = ["Forward", "Right", "Left", "Backward"]
            print(f"Step {self.step_count}: Choosing action {action_names[action]}")

            if collisions:
                # End episode on collision
                is_episode_end = True
                print(f"Collision detected at step {self.step_count}.")
                reward = self.maze_navigator.calculate_reward(is_collision=True)
                self.total_reward += reward
                
                # Update Q-value for current state and action
                next_state = current_state  # In case of collision, we remain in the same state
                self.q_learning_agent.update_q_value(current_state, action, reward, next_state)
                
                # Apply unsticking procedure
                self.unsticking_controller.unstick(collisions)
                #self.move_backward()
                print("Completed unstick, starting new episode...")
                #self.run_episode()
                break
                #continue
                #return
            
            # Execute action
            if not collisions:
                self.execute_action(action)
        if not self.is_goal_reached:
            self.run_episode()
            
    def end_movement(self):
        print(f"Ending movement")
        global current_state
        global action
        #Get new state
        next_state = self.maze_navigator.get_current_grid_position()
        self.robot.standing() #prevent tripping over self?
        if not next_state:
            print("Error: Unable to get next position.")
            self.is_episode_end = True
            #continue
            #return
        
        #print(f"New position: Grid ")
        print(f"New position: Grid {next_state}")
        
        # Calculate reward
        reward = self.maze_navigator.calculate_reward()
        self.total_reward += reward
        print(f"Reward: {reward:.2f}, Total reward: {self.total_reward:.2f}")
        
        # Update Q-value
        self.q_learning_agent.update_q_value(current_state, action, reward, next_state)
        
        # Update state
        current_state = next_state

        # Check if reached goal
        distance_to_goal = self.maze_navigator.calculate_distance_to_goal_grid()
        if distance_to_goal < 1:
            print(">>>> GOAL REACHED - ENDING EPISODE... <<<<")
            reward = 100  # Additional reward for reaching goal
            self.q_learning_agent.save_q_table() #Update Q Table with the finishing values
            self.total_reward += reward
            self.is_goal_reached = True
            self.is_episode_end = True
            #continue
        
        # Pause for a brief moment to allow robot to stabilize
        time_steps = int(100 / self.robot._control_step)  # 100ms pause
        for _ in range(time_steps):
            self.robot._robot.step(self.robot._control_step)
        
        # Update exploration rate
        self.q_learning_agent.update_exploration_rate()
        
        # Save Q-table periodically
        if self.episode_count % 10 == 0:
            print(">>>> SAVING Q TABLE <<<<")
            self.q_learning_agent.save_q_table()
            self.q_learning_agent.print_policy()
        
        # Display episode information
        self.display_episode_info(current_state)

        # Check if max steps reached
        if self.step_count >= self.steps_per_episode:
            print(f"Maximum steps ({self.steps_per_episode}) reached. Ending episode.")
            self.is_episode_end = True
            #self.run_episode() #NEEDED?
            #continue
        else:
            print(">>>> ENDED STEP " + str(self.step_count) + " <<<<")
            #self.run_episode()
        
    
    def execute_action(self, locAction):
        """Execute the given action on the robot."""
        if locAction == 0:  # Move forward
            self.move_forward()
        elif locAction == 1:  # Turn right
            self.turn_right()
            self.move_forward()
        elif locAction == 2:  # Turn left
            self.turn_left()
            self.move_forward()
        elif locAction == 3:  # Move backward
            self.move_backward()
    
    def move_forward(self):
        """Move the robot forward."""
        print("Moving forward...")
        for _ in range(25):  # Adjust number of steps as needed
            # Use the existing compute_walking_position method
            for leg_id in range(4):
                motor_positions = self.robot.compute_walking_position(
                    self.robot._step_count * (self.robot._control_step / 1000),
                    1.5,  # frequency
                    0,    # gait type (trot)
                    leg_id,
                    0.7,  # stride length
                    False  # not backward
                )
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][0], motor_positions[0])
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][1], motor_positions[1])
            
            # Step simulation
            self.robot._robot.step(self.robot._control_step)
            self.robot._step_count += 1
            
            # Apply balance correction during movement
            self.balance_controller.apply_balance_correction()
        #CALL BACK TO REWARD FUNCTION HERE
        #LOLOLOLOLOL
        self.end_movement()
    
    def turn_right(self):
        #Turn the robot right.
        print("Turning right...")
        for _ in range(40):  # Adjust number of steps as needed
            # Right legs move backward, left legs move forward
            for leg_id in range(4):
                stride_factor = -0.3 if leg_id % 2 == 0 else 0.3  # Right legs back, left legs forward
                
                motor_positions = self.robot.compute_walking_position(
                    self.robot._step_count * (self.robot._control_step / 1000),
                    1.0,  # frequency
                    0,    # gait type (trot)
                    leg_id,
                    stride_factor,
                    leg_id % 2 == 0  # backward for right legs
                )
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][0], motor_positions[0])
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][1], motor_positions[1])
            
            # Step simulation
            self.robot._robot.step(self.robot._control_step)
            self.robot._step_count += 1
            
            # Apply balance correction during turning
            self.balance_controller.apply_balance_correction()
        #self.move_forward() #Done in execute_action
        #REWARD CALLBACK
        #self.end_movement()
    
    def turn_left(self):
        #Turn the robot left.
        print("Turning left...")
        for _ in range(40):  # Adjust number of steps as needed
            # Left legs move backward, right legs move forward
            for leg_id in range(4):
                stride_factor = 0.3 if leg_id % 2 == 0 else -0.3  # Right legs forward, left legs back
                
                motor_positions = self.robot.compute_walking_position(
                    self.robot._step_count * (self.robot._control_step / 1000),
                    1.0,  # frequency
                    0,    # gait type (trot)
                    leg_id,
                    stride_factor,
                    leg_id % 2 != 0  # backward for left legs
                )
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][0], motor_positions[0])
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][1], motor_positions[1])
            
            # Step simulation
            self.robot._robot.step(self.robot._control_step)
            self.robot._step_count += 1
            
            # Apply balance correction during turning
            self.balance_controller.apply_balance_correction()
        #self.move_forward() #Done in execute_action
        #REWARD CALLBACK
        #self.end_movement()
    
    def move_backward(self):
        """Move the robot backward."""
        print("Moving backward...")
        for _ in range(75):  # Adjust number of steps as needed
            # Use the existing compute_walking_position method with backward flag
            for leg_id in range(4):
                motor_positions = self.robot.compute_walking_position(
                    self.robot._step_count * (self.robot._control_step / 1000),
                    1.0,  # frequency
                    0,    # gait type (trot)
                    leg_id,
                    0.5,  # stride length
                    True  # backward
                )
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][0], motor_positions[0])
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][1], motor_positions[1])
            
            # Step simulation
            self.robot._robot.step(self.robot._control_step)
            self.robot._step_count += 1
            
            # Apply balance correction during movement
            self.balance_controller.apply_balance_correction()
        #REWARD CALLBACK
        MainController.end_movement(self)
    
    def display_episode_info(self, current_state):
        """Display information about the current episode."""
        print("\n" + "="*50)
        print(f"Episode: {self.episode_count}")
        print(f"Steps: {self.step_count}")
        print(f"Total Reward: {self.total_reward:.2f}")
        print(f"Current Position: Grid {current_state}")
        print(f"Goal Position: Grid {self.maze_navigator.goal_grid}")
        print(f"Distance to Goal: {self.maze_navigator.calculate_distance_to_goal_grid():.2f} grid cells")
        print(f"Exploration Rate: {self.q_learning_agent.exploration_rate:.4f}")
        print("="*50 + "\n")
    
    def run(self, num_episodes=1000):
        """Run the main control loop for a number of episodes."""
        print(f"Starting training for {num_episodes} episodes...")
        self.run_episode()
        #for _ in range(num_episodes):
            #print("Called for new episode (disabled)")
            #self.run_episode()