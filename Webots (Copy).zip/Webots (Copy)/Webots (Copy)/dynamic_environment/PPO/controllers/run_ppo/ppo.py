# ppo.py
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.distributions import Categorical
import pickle
import os
import math
import time

# Set device for PyTorch
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# For numerical stability
EPSILON = 1e-8

class ActorCritic(nn.Module):
    """
    Combined actor-critic network for PPO algorithm.
    Actor outputs action probabilities, Critic outputs state values.
    """
    def __init__(self, input_size, hidden_size, output_size):
        super(ActorCritic, self).__init__()
        
        # Shared layers
        self.shared = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU()
        )
        
        # Actor head - policy network
        self.actor = nn.Sequential(
            nn.Linear(hidden_size, hidden_size*2),
            nn.ReLU(),
            nn.Linear(hidden_size*2, output_size)
            # No softmax here, we'll apply it when needed to ensure numerical stability
        )
        
        # Critic head - value network
        self.critic = nn.Sequential(
            nn.Linear(hidden_size, hidden_size*2),
            nn.ReLU(),
            nn.Linear(hidden_size*2, 1)
        )
    
    def forward(self, x):
        """
        Forward pass through the network.
        Returns action probabilities and state value.
        """
        # Handle None or invalid inputs
        if x is None:
            raise ValueError("Input state is None")
            
        # Convert to tensor if necessary
        if not isinstance(x, torch.Tensor):
            try:
                x = torch.FloatTensor(x).to(device)
            except:
                raise ValueError(f"Cannot convert input to tensor: {x}")
                
        # Check for NaN values in input
        if torch.isnan(x).any():
            print(f"WARNING: NaN values detected in forward input: {x}")
            # Replace NaN with zeros for stability
            x = torch.nan_to_num(x, nan=0.0)
            
        # Ensure proper shape
        if len(x.shape) == 1:
            x = x.unsqueeze(0)  # Add batch dimension if missing
            
        x = x.to(device)
        shared_features = self.shared(x)
        
        # Get logits (unnormalized)
        action_logits = self.actor(shared_features)
        
        # Apply softmax to get action probabilities with numerical stability
        action_probs = F.softmax(action_logits, dim=-1)
        
        # Add small epsilon to prevent exact zeros
        action_probs = action_probs + EPSILON
        action_probs = action_probs / action_probs.sum(dim=-1, keepdim=True)  # Renormalize
        
        # Check for NaN in action probabilities
        if torch.isnan(action_probs).any():
            print(f"WARNING: NaN values in action_probs: {action_probs}")
            # Handle NaN values by replacing with uniform distribution
            action_probs = torch.ones_like(action_probs) / action_probs.size(-1)
        
        # Get state value
        state_value = self.critic(shared_features)
        
        return action_probs, state_value
    
    def get_action(self, state, deterministic=False):
        """
        Sample an action from the policy network.
        
        Args:
            state: Current state observation
            deterministic: If True, choose most likely action; if False, sample from distribution
            
        Returns:
            action: The selected action
            action_log_prob: Log probability of the selected action
            state_value: Value estimation for the state
        """
        # Handle edge cases
        if state is None:
            print("WARNING: State is None in get_action, using random action")
            action = np.random.randint(0, 4)  # Assuming 4 actions
            return action, 0.0, torch.tensor([0.0]).to(device)
            
        # Get action probabilities and state value
        action_probs, state_value = self.forward(state)
        
        # Create distribution
        try:
            dist = Categorical(action_probs)
        except ValueError as e:
            print(f"ERROR creating Categorical distribution: {e}")
            print(f"Action probs: {action_probs}")
            # Return a fallback action
            action = np.random.randint(0, 4)
            return action, 0.0, torch.tensor([0.0]).to(device)
        
        if deterministic:
            # Choose the most likely action
            action = torch.argmax(action_probs, dim=-1)
        else:
            # Sample from the distribution
            action = dist.sample()
        
        # Get log probability
        action_log_prob = dist.log_prob(action)
        
        return action.item(), action_log_prob, state_value


class PPOMemory:
    """
    Memory buffer for PPO algorithm to store trajectories.
    """
    def __init__(self, batch_size):
        self.states = []
        self.actions = []
        self.action_log_probs = []
        self.rewards = []
        self.dones = []
        self.values = []
        self.batch_size = batch_size
    
    def store(self, state, action, action_log_prob, reward, done, value):
        """Store a transition in memory."""
        # Check for valid state
        if state is None:
            print("WARNING: Attempted to store None state in memory")
            return
            
        self.states.append(state)
        self.actions.append(action)
        self.action_log_probs.append(action_log_prob)
        self.rewards.append(reward)
        self.dones.append(done)
        self.values.append(value)
    
    def clear(self):
        """Clear the memory buffer."""
        self.states = []
        self.actions = []
        self.action_log_probs = []
        self.rewards = []
        self.dones = []
        self.values = []
    
    def generate_batches(self):
        """
        Generate mini-batches for training.
        
        Returns:
            Lists of batched states, actions, old_log_probs, returns, and advantages
        """
        n_states = len(self.states)
        batch_start = np.arange(0, n_states, self.batch_size)
        indices = np.arange(n_states, dtype=np.int64)
        np.random.shuffle(indices)
        batches = [indices[i:i+self.batch_size] for i in batch_start]
        
        return batches


class PPOAgent:
    """
    Agent implementing the PPO algorithm.
    """
    def __init__(self, grid_size, num_actions=4, learning_rate=0.0001, gamma=0.99, 
             gae_lambda=0.95, policy_clip=0.2, batch_size=64, n_epochs=10, 
             hidden_size=256, entropy_coef=0.01, value_coef=0.5):
        self.grid_size = grid_size
        self.num_actions = num_actions  # forward, right, left, wait
        self.actions = [0, 1, 2, 3]  # 0=forward, 1=right, 2=left, 3=wait
    
        # PPO hyperparameters
        self.learning_rate = learning_rate  # Reduced learning rate for stability
        self.gamma = gamma
        self.gae_lambda = gae_lambda
        self.policy_clip = policy_clip
        self.batch_size = batch_size
        self.n_epochs = n_epochs
        self.hidden_size = hidden_size
        self.entropy_coef = entropy_coef
        self.value_coef = value_coef
    
        # Initialize memory buffer
        self.memory = PPOMemory(batch_size)
    
        # For exploration rate decay
        self.exploration_rate = 1.0
        self.min_exploration_rate = 0.05
        self.exploration_decay = 0.995
    
        # Initialize neural network
        # Input size: distance to goal (1) + lidar readings (32)
        self.input_size = 33  # 1 (dist to goal) + 32 (lidar readings)
    
        # Initialize actor-critic network
        self.network = ActorCritic(self.input_size, self.hidden_size, self.num_actions).to(device)
    
        # Initialize optimizer
        self.optimizer = optim.Adam(self.network.parameters(), lr=self.learning_rate)
    
        print(f"PPO Agent initialized with grid size {grid_size}")
        print(f"PPO Agent has {self.num_actions} actions available")
        print(f"Using device: {device}")
        print(f"Input size: {self.input_size} (1 distance + {self.input_size-1} LiDAR readings)")
    
    def choose_action(self, state, evaluation=False):
        """
        Choose an action using the policy network with exploration rate.
        
        Args:
            state: Current state observation
            evaluation: If True, use deterministic action selection
            
        Returns:
            action: The selected action
        """
        if state is None:
            print("PPO: State was None, choosing random action")
            return np.random.choice(self.actions)
        
        # Extract grid coordinates if applicable
        if hasattr(state, '__len__') and len(state) == 2 and isinstance(state[0], (int, float)) and isinstance(state[1], (int, float)):
            x, y = state
            
            # Ensure state is within grid bounds
            if x < -self.grid_size[0] or x >= self.grid_size[0] or y < -self.grid_size[1] or y >= self.grid_size[1]:
                print("PPO: Out of bounds, choosing random action")
                return np.random.choice(self.actions)
        
        # Exploration: choose a random action
        if not evaluation and np.random.random() < self.exploration_rate:
            print("PPO: Exploration active, choosing random action")
            return np.random.choice(self.actions)
        
        # Exploitation: choose action using the policy network
        print("PPO: Using policy network for action selection")
        action, _, _ = self.network.get_action(state, deterministic=evaluation)
        return action
    
    def store_transition(self, state, action, action_log_prob, reward, done, value):
        """Store a transition in memory."""
        # Sanity check for action_log_prob
        if isinstance(action_log_prob, torch.Tensor):
            # Detach from computation graph and convert to CPU
            action_log_prob = action_log_prob.detach().cpu().item()
        
        # Sanity check for value
        if isinstance(value, torch.Tensor):
            # Ensure value is a scalar
            if value.numel() == 1:
                value = value.detach().cpu().item()
            else:
                value = value.detach().cpu().squeeze().item()
        
        self.memory.store(state, action, action_log_prob, reward, done, value)
    
    def update_exploration_rate(self):
        """Decrease exploration rate over time."""
        self.exploration_rate = max(self.min_exploration_rate, 
                                  self.exploration_rate * self.exploration_decay)
    
    def compute_advantages_and_returns(self, values, rewards, dones):
        """
        Compute advantages using Generalized Advantage Estimation (GAE) and returns.
        """
        advantages = np.zeros(len(rewards), dtype=np.float32)
        returns = np.zeros(len(rewards), dtype=np.float32)
        
        # Last value is zero if the last state is terminal, otherwise it's the predicted value
        last_value = 0 if dones[-1] else values[-1]
        last_advantage = 0
        
        for t in reversed(range(len(rewards))):
            # The TD error (delta)
            delta = rewards[t] + self.gamma * last_value * (1 - dones[t]) - values[t]
            
            # Generalized Advantage Estimation
            advantages[t] = last_advantage = delta + self.gamma * self.gae_lambda * (1 - dones[t]) * last_advantage
            
            # Returns for value function update
            returns[t] = rewards[t] + self.gamma * last_value * (1 - dones[t])
            
            last_value = values[t]
        
        return advantages, returns
    
    def learn(self):
        """
        Update policy and value network using collected trajectories.
        """
        if len(self.memory.states) == 0:
            print("WARNING: No experiences to learn from")
            return
            
        print(f"Learning from {len(self.memory.states)} experiences")
        
        try:
            # Convert lists to tensors, making sure to detach any tensors that require grad
            states = torch.FloatTensor(np.array(self.memory.states)).to(device)
            actions = torch.LongTensor(np.array(self.memory.actions)).to(device)
            
            # Handle action log probabilities (already detached in store_transition)
            old_log_probs = torch.FloatTensor(np.array(self.memory.action_log_probs)).to(device)
            
            # Handle values (already converted to scalars in store_transition)
            values = torch.FloatTensor(np.array(self.memory.values)).to(device)
            
            # Calculate advantages and returns
            advantages, returns = self.compute_advantages_and_returns(
                values.cpu().numpy(), 
                np.array(self.memory.rewards), 
                np.array(self.memory.dones)
            )
            
            # Check for NaN values
            if np.isnan(advantages).any() or np.isnan(returns).any():
                print("WARNING: NaN detected in advantages or returns, skipping learn step")
                self.memory.clear()
                return
                
            advantages = torch.FloatTensor(advantages).to(device)
            returns = torch.FloatTensor(returns).to(device)
            
            # Normalize advantages (helps with training stability)
            if len(advantages) > 1:  # Need at least 2 values to normalize
                advantages = (advantages - advantages.mean()) / (advantages.std() + EPSILON)
            
            # Generate batches
            batches = self.memory.generate_batches()
            
            # Cap n_epochs based on experiences to avoid overfitting
            actual_epochs = min(self.n_epochs, max(1, len(self.memory.states) // 10))
            
            # Update network for multiple epochs
            for _ in range(actual_epochs):
                for batch in batches:
                    # Check if batch is empty
                    if len(batch) == 0:
                        continue
                        
                    # Get batch data
                    batch_states = states[batch]
                    batch_actions = actions[batch]
                    batch_old_log_probs = old_log_probs[batch]
                    batch_advantages = advantages[batch]
                    batch_returns = returns[batch]
                    
                    # Forward pass
                    action_probs, critic_value = self.network(batch_states)
                    
                    # Ensure critic_value has appropriate shape
                    critic_value = critic_value.squeeze()
                    
                    # Ensure batch_returns has same shape as critic_value
                    if batch_returns.shape != critic_value.shape:
                        if len(batch_returns.shape) == 0:  # Scalar
                            batch_returns = batch_returns.unsqueeze(0)
                        if len(critic_value.shape) == 0:  # Scalar
                            critic_value = critic_value.unsqueeze(0)
                    
                    # Calculate new action probabilities and log probabilities
                    try:
                        dist = Categorical(action_probs)
                        new_log_probs = dist.log_prob(batch_actions)
                        entropy = dist.entropy().mean()
                    except ValueError as e:
                        print(f"ERROR in Categorical distribution: {e}")
                        print(f"Action probs: {action_probs}")
                        continue  # Skip this batch
                    
                    # Calculate the ratio (policy / old policy)
                    # Clip to avoid extreme values
                    old_log_probs_clipped = torch.clamp(batch_old_log_probs, min=-20.0, max=20.0)
                    new_log_probs_clipped = torch.clamp(new_log_probs, min=-20.0, max=20.0)
                    ratio = torch.exp(new_log_probs_clipped - old_log_probs_clipped)
                    
                    # Check for NaN or inf values
                    if torch.isnan(ratio).any() or torch.isinf(ratio).any():
                        print("WARNING: NaN/Inf detected in ratio, using safe values")
                        ratio = torch.clamp(ratio, 0.5, 2.0)  # Reasonable bounds
                        if torch.isnan(ratio).any():  # If still NaN
                            ratio = torch.ones_like(ratio)
                    
                    # Calculate surrogate losses with clipping
                    surr1 = ratio * batch_advantages
                    surr2 = torch.clamp(ratio, 1.0 - self.policy_clip, 1.0 + self.policy_clip) * batch_advantages
                    
                    # Calculate actor loss (negative because we're maximizing)
                    actor_loss = -torch.min(surr1, surr2).mean()
                    
                    # Calculate critic loss (MSE)
                    critic_loss = F.mse_loss(critic_value, batch_returns)
                    
                    # Calculate total loss
                    total_loss = actor_loss + self.value_coef * critic_loss - self.entropy_coef * entropy
                    
                    # Check if loss is valid
                    if torch.isnan(total_loss).any():
                        print("WARNING: NaN detected in total_loss, skipping update")
                        continue
                    
                    # Update networks
                    self.optimizer.zero_grad()
                    total_loss.backward()
                    
                    # Apply gradient clipping (critical for stability)
                    torch.nn.utils.clip_grad_norm_(self.network.parameters(), max_norm=0.5)
                    
                    self.optimizer.step()
                    
            # Clear memory after update
            self.memory.clear()
            
        except Exception as e:
            print(f"ERROR in learn: {e}")
            self.memory.clear()
    
    def save_model(self, filename='ppo_model.pth'):
        """Save neural network and optimizer state."""
        torch.save({
            'model_state_dict': self.network.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'input_size': self.input_size,
            'hidden_size': self.hidden_size,
            'num_actions': self.num_actions,
            'exploration_rate': self.exploration_rate
        }, filename)
        print(f"Model saved to {filename}")
    
    def load_model(self, filename='ppo_model.pth'):
        """Load neural network and optimizer state if file exists."""
        if os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location=device)
                self.network.load_state_dict(checkpoint['model_state_dict'])
                self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
                print(f"Model loaded from {filename}")
                return True
            except Exception as e:
                print(f"Error loading model: {e}")
                return False
        else:
            print(f"No model file found at {filename}")
            return False
    
    def print_policy(self):
        """
        Print the current policy (best action for each state).
        For visualization purposes.
        """
        action_symbols = ['↑', '→', '←', '⊙']  # Forward, Right, Left, Wait
        
        print("\nCurrent Policy:")
        print("-" * (self.grid_size[0] * 2 + 1))
        
        # Create a sample state for each grid position
        for y in range(self.grid_size[1] - 1, -1, -1):  # Print from top to bottom
            row = "|"
            for x in range(-self.grid_size[0], self.grid_size[0]):
                # Create a mock state for this grid position
                # For policy display, we need to encode position in state
                # Calculate approximate distance to goal from this position
                goal_x, goal_y = 3, 8  # Goal position
                dx = abs(x - goal_x)
                dy = abs(y - goal_y)
                dist_to_goal = np.sqrt(dx**2 + dy**2) / np.sqrt((self.grid_size[0] * 2)**2 + (self.grid_size[1] * 2)**2)
                
                # Create mock state with distance to goal and default LiDAR readings
                mock_state = np.zeros(self.input_size)
                mock_state[0] = dist_to_goal
                
                # For visualization, set some basic LiDAR readings
                # Simulate walls at grid boundaries
                if x <= -self.grid_size[0] + 1:
                    mock_state[5:8] = 0.2  # Left side LiDAR readings show closer obstacles
                if x >= self.grid_size[0] - 1:
                    mock_state[13:16] = 0.2  # Right side LiDAR readings show closer obstacles
                if y <= -self.grid_size[1] + 1:
                    mock_state[1:4] = 0.2  # Front LiDAR readings show closer obstacles
                if y >= self.grid_size[1] - 1:
                    mock_state[9:12] = 0.2  # Back LiDAR readings show closer obstacles
                
                # Get action using the network
                try:
                    action, _, _ = self.network.get_action(mock_state, deterministic=True)
                    row += action_symbols[action] + "|"
                except Exception as e:
                    print(f"Error getting policy action: {e}")
                    row += "?|"  # Fallback symbol if error
            print(row)
            print("-" * (self.grid_size[0] * 2 + 1))