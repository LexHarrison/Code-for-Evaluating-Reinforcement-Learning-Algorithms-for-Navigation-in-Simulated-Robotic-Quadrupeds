# maze_navigation.py
import math
import numpy as np
import zmq

contextIN = zmq.Context()
socketIN = contextIN.socket(zmq.REQ) #Subscribe to notifications from main controller
socketIN.connect("tcp://localhost:5568")  # Bind to a port
#socketIN.setsockopt_string(zmq.SUBSCRIBE, "")

class MazeNavigator:
    def __init__(self, robot, sensor_processor, world_size=(10, 10), grid_cell_size=0.5):
        #print(">>>> INIT CALLED <<<<")
        self.robot = robot
        self.sensor_processor = sensor_processor
        self.world_size = world_size
        self.grid_cell_size = grid_cell_size
        self.grid_size = (int(world_size[0] / grid_cell_size), int(world_size[1] / grid_cell_size))

        #print("MAZENAV: Waiting for supervisor...")
        """try:
            message = socketIN.recv_string(flags=zmq.NOBLOCK) #Blocking until supervisor sends us info.
            print("MAZENAV: Got goal coords: " + str(message))
        except zmq.Again:
            pass"""
        #socketIN.send_string("goalPos")
        #response = socketIN.recv_string() #Blocks until response
        
        # Define start and goal positions (grid coordinates)
        self.start_grid = (-8, 7)  # Bottom left
        #self.goal_grid = (3, 8)
        self.goal_grid = (0,0)#(message[0],message[1])#(3, 8)
        
        # Convert grid positions to world coordinates
        self.start_world = self.grid_to_world(self.start_grid)
        #self.goal_world = self.grid_to_world(self.goal_grid)
        self.goal_world = (2.18, 3.61, 0.0) #self.grid_to_world(self.goal_grid)

        self.goal_grid = self.world_to_grid(self.goal_world)
        
        # Calculate maximum possible distance in the grid for normalization
        self.max_distance = np.sqrt((self.grid_size[0] * 2)**2 + (self.grid_size[1] * 2)**2)
        
        print(f"Maze configured: Grid size {self.grid_size}")
        print(f"Start at grid {self.start_grid}, world {self.start_world}")
        print(f"Goal at grid {self.goal_grid}, world {self.goal_world}")
    
    def grid_to_world(self, grid_pos):
        """Convert grid position to world coordinates."""
        x = grid_pos[0] * self.grid_cell_size + self.grid_cell_size / 2
        z = grid_pos[1] * self.grid_cell_size + self.grid_cell_size / 2
        return (x, 0, z)  # Assuming y-up in Webots
    
    @staticmethod
    def clamp(minimum, x, maximum):
        return max(minimum, min(x, maximum))
    
    @staticmethod
    def clip(val, min_, max_, blank):
        return min_ if val < min_ else max_ if val > max_ else val

    def world_to_grid(self, world_pos):
        """Convert world coordinates to grid position."""
        if world_pos is None:
            return None
            
        x = float(world_pos[0] / self.grid_cell_size)
        y = float(world_pos[1] / self.grid_cell_size)  # z in world corresponds to y in grid
        
        # Ensure grid position is within bounds
        x = MazeNavigator.clamp(-self.grid_size[0], math.floor(x) if x < 0 else round(x), self.grid_size[0])
        y = MazeNavigator.clamp(-self.grid_size[1], math.floor(y) if y < 0 else round(y), self.grid_size[1])

        # Round to closest int
        x = round(x)
        y = round(y)
        return (x, y)
    
    def get_current_grid_position(self):
        """Get current grid position based on GPS."""
        world_pos = self.sensor_processor.get_gps_coordinates()
        return self.world_to_grid(world_pos)
    
    def calculate_distance_to_goal_grid(self):
        """Calculate Manhattan distance to goal in grid coordinates."""
        current_grid = self.get_current_grid_position()
        if not current_grid:
            return float('inf')
            
        dx = abs(current_grid[0] - self.goal_grid[0])
        dy = abs(current_grid[1] - self.goal_grid[1])
        return dx + dy
    
    def get_distance_to_goal(self):
        """Get normalized Euclidean distance to goal for PPO agent."""
        current_grid = self.get_current_grid_position()
        if not current_grid:
            return 1.0  # Max normalized distance if position unknown
            
        dx = current_grid[0] - self.goal_grid[0]
        dy = current_grid[1] - self.goal_grid[1]
        distance = np.sqrt(dx**2 + dy**2)
        
        # Normalize distance to [0, 1] range
        normalized_distance = min(1.0, distance / self.max_distance)
        
        return normalized_distance
    
    def calculate_reward(self, is_collision=False, is_fall=False):
        """Calculate reward based on distance to goal and penalties."""
        if is_collision:
            return -100  # Large penalty for collision
        
        if is_fall:
            return -50  # Penalty for falling
        
        # Calculate current distance to goal
        current_distance = self.calculate_distance_to_goal_grid()
        
        # Base reward on distance (closer to goal = less negative reward)
        max_distance = self.grid_size[0] + self.grid_size[1]
        
        # Scale reward to be between -10 and -1 based on distance
        distance_reward = -10 + 9 * (1 - (current_distance / max_distance))
        
        # Check if reached goal
        if current_distance < 1:  # Within one grid cell of goal
            return 100  # Large reward for reaching goal
            
        return distance_reward
