# replay_buffer.py
import numpy as np
from collections import deque
import random

class ReplayBuffer:
    """
    Experience replay buffer for DQN agent.
    Stores transitions (state, action, reward, next_state, done) and provides 
    sampling functionality for batch training.
    """
    def __init__(self, capacity):
        """
        Initialize replay buffer with fixed capacity.
        
        Args:
            capacity (int): Maximum number of transitions to store
        """
        self.buffer = deque(maxlen=capacity)
    
    def add(self, state, action, reward, next_state, done):
        """
        Add a new transition to the buffer.
        
        Args:
            state: Current state
            action: Action taken
            reward: Reward received
            next_state: Next state after taking action
            done: Boolean indicating if episode terminated
        """
        self.buffer.append((state, action, reward, next_state, done))
    
    def sample(self, batch_size):
        """
        Sample a batch of transitions from the buffer.
        
        Args:
            batch_size (int): Number of transitions to sample
            
        Returns:
            tuple: (states, actions, rewards, next_states, dones) - Batch of experiences
        """
        batch = random.sample(self.buffer, batch_size)
        states, actions, rewards, next_states, dones = zip(*batch)
        
        # Convert to numpy arrays for TensorFlow
        return (
            np.array(states),
            np.array(actions, dtype=np.int32),
            np.array(rewards, dtype=np.float32),
            np.array(next_states),
            np.array(dones, dtype=np.float32)
        )
    
    def size(self):
        """
        Get the current size of the buffer.
        
        Returns:
            int: Current number of transitions in buffer
        """
        return len(self.buffer)