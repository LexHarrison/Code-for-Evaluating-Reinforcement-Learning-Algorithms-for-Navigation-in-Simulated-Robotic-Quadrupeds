# main_controller.py
from controller import Robot
from python_controller import BioloidRobot
from python_controller import FRONT_LEFT_1, FRONT_RIGHT_1, FRONT_LEFT_2, FRONT_RIGHT_2, FRONT_LEFT_3, FRONT_RIGHT_3
from python_controller import BACK_LEFT_1, BACK_RIGHT_1, BACK_LEFT_2, BACK_RIGHT_2, BACK_LEFT_3, BACK_RIGHT_3
from python_controller import NECK_1, NECK_2, HEAD, PELVIS
from balance import BalanceController
from sensor_tuning import SensorProcessor
from unsticking import UnstickingController
from maze_navigation import MazeNavigator
from ppo import PPOAgent  # Import PPO agent instead of Q-learning
import time
import numpy as np
import torch

class MainController:
    def __init__(self):
        # Initialize the robot
        print("Initializing robot controller...")
        self.webots_robot = Robot()
        self.robot = BioloidRobot(self.webots_robot)
        
        # Define gait setup
        self.GAIT_SETUP = [
            [FRONT_LEFT_1, FRONT_LEFT_3],
            [FRONT_RIGHT_1, FRONT_RIGHT_3],
            [BACK_RIGHT_1, BACK_RIGHT_3],
            [BACK_LEFT_1, BACK_LEFT_3]
        ]
        
        # Initialize modules
        print("Setting up sensor processor...")
        self.sensor_processor = SensorProcessor(self.robot)
        
        print("Setting up balance controller...")
        self.balance_controller = BalanceController(self.robot)
        
        print("Setting up maze navigator...")
        self.maze_navigator = MazeNavigator(self.robot, self.sensor_processor)
        
        print("Setting up PPO agent...")
        # Initialize PPO agent with 4 actions: forward, right, left, wait
        self.ppo_agent = PPOAgent(self.maze_navigator.grid_size, num_actions=4)
        
        # Episode tracking
        self.episode_count = 0
        self.step_count = 0
        self.steps_per_episode = 200  # Increased from 50 to give more time to reach goal
        self.total_reward = 0
        self.best_total_reward = float('-inf')  # Track best episode reward

        self.is_goal_reached = False
        self.is_episode_end = False
        
        # Setup robot
        print("Initializing robot...")
        self.robot.init_camera()
        
        # Calibrate IMU
        print("Calibrating IMU...")
        self.balance_controller.calibrate()
        
        # Set robot to standing position
        self.robot.standing()
        
        # Now that all other initialization is done, set up unsticking controller
        # to avoid circular import
        print("Setting up unsticking controller...")
        self.unsticking_controller = UnstickingController(self.robot, self.sensor_processor, self)
        
        # Load model if available
        try:
            self.ppo_agent.load_model('ppo_model.pth')
        except Exception as e:
            print(f"Note: Could not load model: {e}")
        
        print("Robot controller initialization complete.")
    
    def run_episode(self, evaluation=False):
        """Run a single episode."""
        self.episode_count += 1
        self.step_count = 0
        self.total_reward = 0
        
        print(f">>>> Starting Episode {self.episode_count} <<<<")
        
        # Get initial state
        current_state = self.get_state()
        if current_state is None:
            print("Error: Unable to get current state.")
            return False
        
        print(f"Initial position: Grid {self.maze_navigator.get_current_grid_position()}")
        
        # Reset robot to standing position
        self.robot.standing()
        
        # Run steps until episode ends
        self.is_episode_end = False
        self.is_goal_reached = False
        
        # Display the current policy every 10 episodes
        if self.episode_count % 10 == 0 and not evaluation:
            print("Current policy visualization:")
            self.ppo_agent.print_policy()
        
        while not self.is_episode_end:
            if self.is_goal_reached:
                print(">>>> GOAL REACHED, TERMINATING... <<<<")
                break

            # Increment step count
            self.step_count += 1
            # Check for maximum steps in a single episode (not maximum episodes)
            if self.step_count > self.steps_per_episode:
                print(f"Maximum steps ({self.steps_per_episode}) per episode reached, ending this episode.")
                self.is_episode_end = True
                break
            
            # Check balance
            if self.balance_controller.is_falling():
                print("MAINCONT: Robot is losing balance. Applying correction...")
                self.balance_controller.apply_balance_correction()
                
                # If still falling, end episode
                if self.balance_controller.is_falling():
                    print("MAINCONT: Robot is falling. Ending episode.")
                    reward = self.maze_navigator.calculate_reward(is_fall=True)
                    self.total_reward += reward
                    self.is_episode_end = True
                    break
            
            # Check for collisions
            collisions = self.sensor_processor.detect_collisions()

            # PPO action selection
            # During evaluation (testing), we select actions deterministically
            # During training, we sample from the policy distribution
            try:
                if evaluation:
                    action = self.ppo_agent.choose_action(current_state, evaluation=True)
                    action_log_prob = 0  # Not used during evaluation
                    value = 0  # Not used during evaluation
                else:
                    # Get action, log probability, and value from network
                    action, action_log_prob, value = self.ppo_agent.network.get_action(current_state)
                    
                    # Validate values
                    if isinstance(action, torch.Tensor):
                        action = action.item()
                    
                    # Ensure action is a valid integer
                    if not isinstance(action, (int, np.integer)):
                        print(f"WARNING: Invalid action type: {type(action)}, using random action")
                        action = np.random.choice([0, 1, 2, 3])
            except Exception as e:
                print(f"Error in action selection: {e}")
                action = np.random.choice([0, 1, 2, 3])
                action_log_prob = 0
                value = 0
                
            # Validate action value
            if action not in [0, 1, 2, 3]:
                print(f"WARNING: Invalid action value: {action}, using random action")
                action = np.random.choice([0, 1, 2, 3])
            
            action_names = ["Forward", "Right", "Left", "Wait"]
            print(f"Step {self.step_count}: Choosing action {action_names[action]}")
            current_grid_pos = self.maze_navigator.get_current_grid_position()
            print(f"Current position: Grid {current_grid_pos}")

            if collisions:
                # End episode on collision
                self.is_episode_end = True
                print(f"Collision detected at step {self.step_count}.")
                reward = self.maze_navigator.calculate_reward(is_collision=True)
                self.total_reward += reward
                
                # Store transition in the buffer if training
                if not evaluation:
                    try:
                        self.ppo_agent.store_transition(
                            current_state, action, action_log_prob, reward, True, value
                        )
                    except Exception as e:
                        print(f"Error storing transition after collision: {e}")
                
                # Apply unsticking procedure
                self.unsticking_controller.unstick(collisions)
                print("Completed unstick, starting new episode...")
                break
            
            # Execute action if no collisions
            if not collisions:
                if action == 3:  # Wait action
                    # Just do nothing for a bit
                    time_steps = int(500 / self.robot._control_step)
                    for _ in range(time_steps):
                        self.robot._robot.step(self.robot._control_step)
                else:
                    self.execute_action(action)
                    
            # Get new state
            next_state = self.get_state()
            
            # Reset to standing position
            self.robot.standing()
            
            if next_state is None:
                print("Error: Unable to get next state.")
                self.is_episode_end = True
                break
            
            # Calculate reward
            reward = self.maze_navigator.calculate_reward()
            self.total_reward += reward
            print(f"Reward: {reward:.2f}, Total reward: {self.total_reward:.2f}")
            
            # Check if reached goal
            distance_to_goal = self.maze_navigator.calculate_distance_to_goal_grid()
            is_done = False
            
            if distance_to_goal < 1:
                print(">>>> GOAL REACHED - ENDING EPISODE... <<<<")
                goal_reward = 100  # Additional reward for reaching goal
                reward += goal_reward
                self.total_reward += goal_reward
                self.is_goal_reached = True
                self.is_episode_end = True
                is_done = True
            
            # Store transition in the buffer if training
            if not evaluation:
                try:
                    self.ppo_agent.store_transition(
                        current_state, action, action_log_prob, reward, is_done, value
                    )
                except Exception as e:
                    print(f"Error storing transition: {e}")
            
            # Update current state
            current_state = next_state
            
            # Pause for a brief moment to allow robot to stabilize
            time_steps = int(100 / self.robot._control_step)
            for _ in range(time_steps):
                self.robot._robot.step(self.robot._control_step)
            
            # Display episode information
            self.display_episode_info()
        
        # Update PPO agent if we have enough experiences and not in evaluation mode
        if not evaluation and len(self.ppo_agent.memory.states) > 0:
            try:
                self.ppo_agent.learn()
                
                # Update exploration rate
                self.ppo_agent.update_exploration_rate()
                
                # Save model if this is the best episode so far
                if self.total_reward > self.best_total_reward:
                    self.best_total_reward = self.total_reward
                    self.ppo_agent.save_model('ppo_model.pth')
                    print(f"New best model saved with reward: {self.best_total_reward:.2f}")
                
                # Periodically save model
                if self.episode_count % 10 == 0:
                    self.ppo_agent.save_model(f'ppo_model_ep{self.episode_count}.pth')
                    
                # Print policy periodically to see how it's evolving
                if self.episode_count % 10 == 0:
                    self.ppo_agent.print_policy()
            except Exception as e:
                print(f"Error in PPO learning step: {e}")
        
        # Return whether goal was reached to the main loop
        return self.is_goal_reached
    
    def get_state(self):
        """
        Construct the state vector for the PPO agent.
        """
        # Get current grid position
        grid_pos = self.maze_navigator.get_current_grid_position()
        if grid_pos is None:
            return None
        
        # Get distance to goal (normalized)
        distance_to_goal = self.maze_navigator.get_distance_to_goal()
        
        # Get LiDAR data (normalized)
        lidar_data = self.sensor_processor.get_lidar_data_normalized()
        if lidar_data is None:
            # If LiDAR data is unavailable, use a default vector
            lidar_data = np.zeros(16)  # Assuming 16 LiDAR readings
        
        # Verify data quality - no NaNs or infinities
        if not np.isfinite(distance_to_goal) or not np.all(np.isfinite(lidar_data)):
            print("WARNING: Non-finite values in state, normalizing")
            if not np.isfinite(distance_to_goal):
                distance_to_goal = 1.0  # Assume far from goal
            lidar_data = np.nan_to_num(lidar_data, nan=1.0, posinf=1.0, neginf=0.0)
        
        # Construct state vector
        state = np.concatenate(([distance_to_goal], lidar_data))
        
        return state
    
    def execute_action(self, action):
        """Execute the given action on the robot."""
        if action == 0:  # Move forward
            self.move_forward()
        elif action == 1:  # Turn right
            self.turn_right()
            self.move_forward()
        elif action == 2:  # Turn left
            self.turn_left()
            self.move_forward()
        elif action == 3:  # Wait (do nothing)
            time_steps = int(500 / self.robot._control_step)
            for _ in range(time_steps):
                self.robot._robot.step(self.robot._control_step)
        else:
            print(f"WARNING: Invalid action: {action}, doing nothing")
            time_steps = int(500 / self.robot._control_step)
            for _ in range(time_steps):
                self.robot._robot.step(self.robot._control_step)
    
    def move_forward(self):
        """Move the robot forward."""
        print("Moving forward...")
        for _ in range(25):  # Adjust number of steps as needed
            # Use the existing compute_walking_position method
            for leg_id in range(4):
                motor_positions = self.robot.compute_walking_position(
                    self.robot._step_count * (self.robot._control_step / 1000),
                    1.5,  # frequency
                    0,    # gait type (trot)
                    leg_id,
                    0.7,  # stride length
                    False  # not backward
                )
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][0], motor_positions[0])
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][1], motor_positions[1])
            
            # Step simulation
            self.robot._robot.step(self.robot._control_step)
            self.robot._step_count += 1
            
            # Apply balance correction during movement
            self.balance_controller.apply_balance_correction()
    
    def turn_right(self):
        """Turn the robot right."""
        print("Turning right...")
        for _ in range(40):  # Adjust number of steps as needed
            # Right legs move backward, left legs move forward
            for leg_id in range(4):
                stride_factor = -0.3 if leg_id % 2 == 0 else 0.3  # Right legs back, left legs forward
                
                motor_positions = self.robot.compute_walking_position(
                    self.robot._step_count * (self.robot._control_step / 1000),
                    1.0,  # frequency
                    0,    # gait type (trot)
                    leg_id,
                    stride_factor,
                    leg_id % 2 == 0  # backward for right legs
                )
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][0], motor_positions[0])
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][1], motor_positions[1])
            
            # Step simulation
            self.robot._robot.step(self.robot._control_step)
            self.robot._step_count += 1
            
            # Apply balance correction during turning
            self.balance_controller.apply_balance_correction()
    
    def turn_left(self):
        """Turn the robot left."""
        print("Turning left...")
        for _ in range(40):  # Adjust number of steps as needed
            # Left legs move backward, right legs move forward
            for leg_id in range(4):
                stride_factor = 0.3 if leg_id % 2 == 0 else -0.3  # Right legs forward, left legs back
                
                motor_positions = self.robot.compute_walking_position(
                    self.robot._step_count * (self.robot._control_step / 1000),
                    1.0,  # frequency
                    0,    # gait type (trot)
                    leg_id,
                    stride_factor,
                    leg_id % 2 != 0  # backward for left legs
                )
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][0], motor_positions[0])
                self.robot.set_motor_position(self.GAIT_SETUP[leg_id][1], motor_positions[1])
            
            # Step simulation
            self.robot._robot.step(self.robot._control_step)
            self.robot._step_count += 1
            
            # Apply balance correction during turning
            self.balance_controller.apply_balance_correction()
    
    def display_episode_info(self):
        """Display information about the current episode."""
        print("\n" + "="*50)
        print(f"Episode: {self.episode_count}")
        print(f"Steps: {self.step_count}")
        print(f"Total Reward: {self.total_reward:.2f}")
        print(f"Current Position: Grid {self.maze_navigator.get_current_grid_position()}")
        print(f"Goal Position: Grid {self.maze_navigator.goal_grid}")
        print(f"Distance to Goal: {self.maze_navigator.calculate_distance_to_goal_grid():.2f} grid cells")
        print(f"Exploration Rate: {self.ppo_agent.exploration_rate:.4f}")
        print("="*50 + "\n")
    
    def run(self, num_episodes=5000):
        """Run the main control loop for a number of episodes."""
        print(f"Starting training for up to {num_episodes} episodes...")
        
        episode = 0
        goal_reached = False
        
        try:
            while not goal_reached and episode < num_episodes:
                episode += 1
                print(f"\nStarting episode {episode}/{num_episodes}")
                goal_reached = self.run_episode(evaluation=False)
                
                if goal_reached:
                    print(f"Goal reached in episode {episode}! Continuing training for stability...")
                    # Reset goal_reached to continue training
                    goal_reached = False
                    # Continue for a few more episodes to stabilize the policy
                    for _ in range(min(10, num_episodes - episode)):
                        if episode < num_episodes:
                            episode += 1
                            self.run_episode(evaluation=False)
                    break
            
            # After training, run some evaluation episodes
            print("Training complete. Running evaluation episodes...")
            self.episode_count = 0
            for _ in range(5):
                self.run_episode(evaluation=True)
                
            # Save final model
            self.ppo_agent.save_model('ppo_model_final.pth')
            
            # Display final policy
            print("\nFinal Policy:")
            self.ppo_agent.print_policy()
        
        except Exception as e:
            print(f"Critical error in main loop: {e}")
            # Save model on error for recovery
            self.ppo_agent.save_model('ppo_model_error.pth')