# dqn_learning.py
import numpy as np
import tensorflow as tf
import random
import os
import math
from replay_buffer import ReplayBuffer

class DQNAgent:
    def __init__(self, grid_size, num_actions=4, learning_rate=0.1, discount_factor=0.99, 
                 exploration_rate=1.0, min_exploration_rate=0.01, exploration_decay=0.998,
                 memory_size=10000, batch_size=64, target_update_freq=200):
        self.grid_size = grid_size
        self.actions = [0, 1, 2, 3]  # forward, right, left, wait
        self.num_actions = len(self.actions)
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        self.exploration_rate = exploration_rate
        self.min_exploration_rate = min_exploration_rate
        self.exploration_decay = exploration_decay
        
        # Experience replay parameters
        self.memory_size = memory_size
        self.batch_size = batch_size
        self.replay_buffer = ReplayBuffer(memory_size)
        
        # Target network update frequency
        self.target_update_freq = target_update_freq
        self.update_counter = 0
        
        # Input state dimensions: x, y coordinates
        self.state_dim = 2  
        
        # Create the neural network models
        self.q_network = self._build_model() #BUILDS CLASS Q NETWORK
        self.target_network = self._build_model()
        self.update_target_network()  # Initial copy of weights
        
        print(f"DQN agent initialized with grid size {grid_size}")
        print(f"Initial exploration rate: {self.exploration_rate}")
        print(f"Neural network initialized with {self.state_dim} inputs and {self.num_actions} outputs")
        
    def _build_model(self):
        """Build a neural network to approximate the Q-function."""
        model = tf.keras.Sequential([ # 2 hidden layers
            tf.keras.layers.Dense(64, activation='relu', input_shape=(self.state_dim,)),
            tf.keras.layers.Dense(64, activation='relu'),
            tf.keras.layers.Dense(self.num_actions, activation='linear')
        ])
        model.compile(optimizer=tf.keras.optimizers.Adam(learning_rate=self.learning_rate),
                      loss='mse')
        return model
    
    def update_target_network(self):
        """Update the target network by copying weights from the Q-network."""
        self.target_network.set_weights(self.q_network.get_weights())
        print("Target network updated")
    
    def choose_action(self, state):
        """Choose action using epsilon-greedy policy."""
        if state is None:
            print("ACTIONCHOICE: STATE WAS NONE, CHOOSING RANDOM ACTION")
            return random.choice(self.actions)
        
        # Extract grid coordinates
        x, y = state
    
        # Ensure state is within grid bounds
        if x < -self.grid_size[0] or x >= self.grid_size[0] or y < -self.grid_size[1] or y >= self.grid_size[1]:
            print("ACTIONCHOICE: OUT OF BOUNDS, DOING RANDOM ACTION")
            return random.choice(self.actions)
    
        # Exploration: choose a random action
        if random.random() < self.exploration_rate:
            print("ACTIONCHOICE: EXPLORATION ACTIVE, DOING RANDOM ACTION")
            return random.choice(self.actions)
    
        # Exploitation: choose best action based on Q-network prediction
        print("ACTIONCHOICE: USING DQN PREDICTION")
        # Normalize state input
        norm_state = self._normalize_state(state)
        state_input = norm_state.reshape(1, -1)
        q_values = self.q_network.predict(state_input, verbose=0)[0]
        return np.argmax(q_values)
    
    def update_q_value(self, state, action, reward, next_state):
        """Store experience and update the Q-network if enough samples are available."""
        if state is None or next_state is None:
            print("DQN update: State or next_state is None, skipping update")
            return
        
        # Extract grid coordinates
        x, y = state
        nx, ny = next_state
    
        # Ensure states are within grid bounds
        if (x < -self.grid_size[0] or x >= self.grid_size[0] or y < -self.grid_size[1] or y >= self.grid_size[1] or
            nx < -self.grid_size[0] or nx >= self.grid_size[0] or ny < -self.grid_size[1] or ny >= self.grid_size[1]):
            print("DQN update: State or next_state out of bounds, skipping update")
            return
    
        # Normalize states before adding to replay buffer
        norm_state = self._normalize_state(state)
        norm_next_state = self._normalize_state(next_state)
    
        # Store experience in replay buffer
        self.replay_buffer.add(norm_state, action, reward, norm_next_state, 0)  # 0 for non-terminal state
    
        # Only train if we have enough samples in the replay buffer (buffer warmup)
        min_experiences = self.batch_size * 2
        if self.replay_buffer.size() > min_experiences:
            self.train()
        
        # Update target network periodically
        self.update_counter += 1
        if self.update_counter % self.target_update_freq == 0:
            self.update_target_network()
    
    def train(self):
        """Train the Q-network using a batch of experiences from the replay buffer."""
        # Sample a batch of experiences
        states, actions, rewards, next_states, dones = self.replay_buffer.sample(self.batch_size)
        
        # Calculate target Q-values
        next_q_values = self.target_network.predict(next_states, verbose=0)
        max_next_q = np.max(next_q_values, axis=1)
        target_q_values = rewards + (1 - dones) * self.discount_factor * max_next_q
        
        # Get current Q-values and update with target for the selected actions
        current_q = self.q_network.predict(states, verbose=0)
        for i in range(self.batch_size):
            current_q[i, actions[i]] = target_q_values[i]
        
        # Train the network
        self.q_network.fit(states, current_q, epochs=1, verbose=0)
    
    def update_exploration_rate(self):
        """Decrease exploration rate over time."""
        self.exploration_rate = max(self.min_exploration_rate, 
                                  self.exploration_rate * self.exploration_decay)
    
    def save_model(self, filename='dqn_model'):
        """Save the DQN model."""
        self.q_network.save(filename)
        print(f"DQN model saved to {filename}")
    
    def load_model(self, filename='dqn_model'):
        """Load the DQN model if it exists."""
        if os.path.exists(filename):
            self.q_network = tf.keras.models.load_model(filename)
            self.update_target_network()  # Update target network with loaded weights
            print(f"DQN model loaded from {filename}")
            return True
        print(f"No model file found at {filename}")
        return False
    
    def _normalize_state(self, state):
        """Normalize state values to improve neural network training."""
        x, y = state
        norm_x = x / self.grid_size[0]
        norm_y = y / self.grid_size[1]
        return np.array([norm_x, norm_y])
    
    def print_policy(self):
        """Print the current policy (best action for each state)."""
        action_symbols = ['↑', '→', '←', '⊙']  # Forward, Right, Left, Wait
    
        print("\nCurrent Policy (Sample):")
        print("-" * (10 * 2 + 1))  # Print a smaller sample of the policy
    
        # Sample a subset of the grid for display
        for y in range(5):  # Print a 5x5 sample from the center
            row = "|"
            center_y = self.grid_size[1] // 2 - 2 + y
            for x in range(5):
                center_x = self.grid_size[0] // 2 - 2 + x
                # Normalize state
                norm_state = self._normalize_state((center_x, center_y))
                state_input = norm_state.reshape(1, -1)
                q_values = self.q_network.predict(state_input, verbose=0)[0]
                best_action = np.argmax(q_values)
                row += action_symbols[best_action] + "|"
            print(row)
            print("-" * (10 * 2 + 1))
    
        print("Note: This is a 5x5 sample from the center of the grid")