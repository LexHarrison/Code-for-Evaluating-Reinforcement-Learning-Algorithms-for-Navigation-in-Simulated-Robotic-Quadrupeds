# dqn.py
import numpy as np
import torch
import torch.nn as nn
import torch.optim as optim
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader
import random
import os
import math
import time

# Set device for PyTorch
device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")

# For numerical stability
EPSILON = 1e-8

class ReplayBuffer:
    """
    Experience replay buffer for storing and sampling experiences.
    """
    def __init__(self, capacity):
        self.capacity = capacity
        self.buffer = []
        self.position = 0
        
    def add(self, state, action, reward, next_state, done):
        """Add a new experience to the buffer."""
        if len(self.buffer) < self.capacity:
            self.buffer.append(None)
        self.buffer[self.position] = (state, action, reward, next_state, done)
        self.position = (self.position + 1) % self.capacity
    
    def sample(self, batch_size):
        """Sample a batch of experiences from the buffer."""
        batch = random.sample(self.buffer, batch_size)
        state, action, reward, next_state, done = map(np.array, zip(*batch))
        return state, action, reward, next_state, done
    
    def size(self):
        """Return the current size of the buffer."""
        return len(self.buffer)

class DQNetwork(nn.Module):
    """
    Deep Q-Network for approximating Q-values.
    """
    def __init__(self, input_size, hidden_size, output_size):
        super(DQNetwork, self).__init__()
        
        # Network architecture
        self.hidden1 = nn.Linear(input_size, hidden_size)
        self.hidden2 = nn.Linear(hidden_size, hidden_size * 2)
        self.hidden3 = nn.Linear(hidden_size * 2, hidden_size)
        self.output = nn.Linear(hidden_size, output_size)
        
    def forward(self, x):
        """Forward pass through the network."""
        # Handle None or invalid inputs
        if x is None:
            raise ValueError("Input state is None")
            
        # Convert to tensor if necessary
        if not isinstance(x, torch.Tensor):
            try:
                x = torch.FloatTensor(x).to(device)
            except:
                raise ValueError(f"Cannot convert input to tensor: {x}")
                
        # Check for NaN values in input
        if torch.isnan(x).any():
            print(f"WARNING: NaN values detected in forward input: {x}")
            # Replace NaN with zeros for stability
            x = torch.nan_to_num(x, nan=0.0)
            
        # Ensure proper shape
        if len(x.shape) == 1:
            x = x.unsqueeze(0)  # Add batch dimension if missing
            
        x = x.to(device)
        
        x = F.relu(self.hidden1(x))
        x = F.relu(self.hidden2(x))
        x = F.relu(self.hidden3(x))
        q_values = self.output(x)
        
        return q_values

class DQNAgent:
    """
    Agent implementing the DQN algorithm.
    """
    def __init__(self, grid_size, num_actions=4, learning_rate=0.001, gamma=0.99, 
                batch_size=64, min_replay_size=1000, target_update_freq=1000,
                hidden_size=256, epsilon_start=1.0, epsilon_end=0.05, epsilon_decay=0.995):
        self.grid_size = grid_size
        self.num_actions = num_actions  # forward, right, left, wait
        self.actions = [0, 1, 2, 3]  # 0=forward, 1=right, 2=left, 3=wait
    
        # DQN hyperparameters
        self.learning_rate = learning_rate
        self.gamma = gamma
        self.batch_size = batch_size
        self.min_replay_size = min_replay_size
        self.target_update_freq = target_update_freq
        self.hidden_size = hidden_size
    
        # For exploration rate decay
        self.exploration_rate = epsilon_start
        self.min_exploration_rate = epsilon_end
        self.exploration_decay = epsilon_decay
    
        # Initialize memory buffer
        self.memory = ReplayBuffer(100000)
        
        # Input size: distance to goal (1) + lidar readings (32)
        self.input_size = 33  # 1 (dist to goal) + 32 (lidar readings)
    
        # Initialize Q-networks
        self.q_network = DQNetwork(self.input_size, self.hidden_size, self.num_actions).to(device)
        self.target_network = DQNetwork(self.input_size, self.hidden_size, self.num_actions).to(device)
        self.update_target_network()  # Initialize target network with same weights
    
        # Initialize optimizer
        self.optimizer = optim.Adam(self.q_network.parameters(), lr=self.learning_rate)
        
        # Training tracking
        self.update_counter = 0
    
        print(f"DQN Agent initialized with grid size {grid_size}")
        print(f"DQN Agent has {self.num_actions} actions available")
        print(f"Using device: {device}")
        print(f"Input size: {self.input_size} (1 distance + {self.input_size-1} LiDAR readings)")
    
    def choose_action(self, state, evaluation=False):
        """
        Choose an action using epsilon-greedy policy.
        
        Args:
            state: Current state observation
            evaluation: If True, use deterministic action selection
            
        Returns:
            action: The selected action
        """
        if state is None:
            print("DQN: State was None, choosing random action")
            return np.random.choice(self.actions)
        
        # Exploration: choose a random action with probability epsilon
        if not evaluation and np.random.random() < self.exploration_rate:
            print("DQN: Exploration active, choosing random action")
            return np.random.choice(self.actions)
        
        # Exploitation: choose action with highest Q-value
        print("DQN: Using Q-network for action selection")
        with torch.no_grad():
            q_values = self.q_network(state)
            action = torch.argmax(q_values, dim=1).item()
        return action
    
    def store_transition(self, state, action, reward, next_state, done):
        """Store a transition in memory."""
        self.memory.add(state, action, reward, next_state, done)
    
    def update_exploration_rate(self):
        """Decrease exploration rate over time."""
        self.exploration_rate = max(self.min_exploration_rate, 
                                  self.exploration_rate * self.exploration_decay)
    
    def update_target_network(self):
        """Update the target network with the current Q-network weights."""
        self.target_network.load_state_dict(self.q_network.state_dict())
        print("Target network updated")
    
    def learn(self):
        """
        Update Q-network using a batch of experiences from the replay buffer.
        """
        if self.memory.size() < self.min_replay_size:
            print(f"Not enough experiences in buffer ({self.memory.size()}/{self.min_replay_size})")
            return
            
        print(f"Learning from {self.memory.size()} experiences")
        
        try:
            # Sample a batch of experiences
            states, actions, rewards, next_states, dones = self.memory.sample(self.batch_size)
            
            # Convert to PyTorch tensors
            states = torch.FloatTensor(states).to(device)
            actions = torch.LongTensor(actions).to(device)
            rewards = torch.FloatTensor(rewards).to(device)
            next_states = torch.FloatTensor(next_states).to(device)
            dones = torch.FloatTensor(dones).to(device)
            
            # Calculate current Q-values
            q_values = self.q_network(states)
            # Get Q-value for the action taken
            q_values = q_values.gather(1, actions.unsqueeze(1)).squeeze(1)
            
            # Calculate target Q-values
            with torch.no_grad():
                # Double DQN: Use online network to select action, target network to evaluate
                next_actions = torch.argmax(self.q_network(next_states), dim=1)
                next_q_values = self.target_network(next_states).gather(1, next_actions.unsqueeze(1)).squeeze(1)
                
                # Calculate target using Bellman equation
                targets = rewards + (1 - dones) * self.gamma * next_q_values
            
            # Calculate loss
            loss = F.smooth_l1_loss(q_values, targets)  # Huber loss for stability
            
            # Optimize the model
            self.optimizer.zero_grad()
            loss.backward()
            # Clip gradients for stability
            torch.nn.utils.clip_grad_norm_(self.q_network.parameters(), max_norm=1.0)
            self.optimizer.step()
            
            # Update target network periodically
            self.update_counter += 1
            if self.update_counter % self.target_update_freq == 0:
                self.update_target_network()
                
        except Exception as e:
            print(f"ERROR in learn: {e}")
    
    def save_model(self, filename='dqn_model.pth'):
        """Save neural network and optimizer state."""
        torch.save({
            'q_network_state_dict': self.q_network.state_dict(),
            'target_network_state_dict': self.target_network.state_dict(),
            'optimizer_state_dict': self.optimizer.state_dict(),
            'input_size': self.input_size,
            'hidden_size': self.hidden_size,
            'num_actions': self.num_actions,
            'exploration_rate': self.exploration_rate
        }, filename)
        print(f"Model saved to {filename}")
    
    def load_model(self, filename='dqn_model.pth'):
        """Load neural network and optimizer state if file exists."""
        if os.path.exists(filename):
            try:
                checkpoint = torch.load(filename, map_location=device)
                self.q_network.load_state_dict(checkpoint['q_network_state_dict'])
                self.target_network.load_state_dict(checkpoint['target_network_state_dict'])
                self.optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
                print(f"Model loaded from {filename}")
                return True
            except Exception as e:
                print(f"Error loading model: {e}")
                return False
        else:
            print(f"No model file found at {filename}")
            return False
    
    def print_policy(self):
        """
        Print the current policy (best action for each state).
        For visualization purposes.
        """
        action_symbols = ['↑', '→', '←', '⊙']  # Forward, Right, Left, Wait
        
        print("\nCurrent Policy:")
        print("-" * (self.grid_size[0] * 2 + 1))
        
        # Create a sample state for each grid position
        for y in range(self.grid_size[1] - 1, -1, -1):  # Print from top to bottom
            row = "|"
            for x in range(-self.grid_size[0], self.grid_size[0]):
                # Create a mock state for this grid position
                # Calculate approximate distance to goal from this position
                goal_x, goal_y = 3, 8  # Goal position
                dx = abs(x - goal_x)
                dy = abs(y - goal_y)
                dist_to_goal = np.sqrt(dx**2 + dy**2) / np.sqrt((self.grid_size[0] * 2)**2 + (self.grid_size[1] * 2)**2)
                
                # Create mock state with distance to goal and default LiDAR readings
                mock_state = np.zeros(self.input_size)
                mock_state[0] = dist_to_goal
                
                # For visualization, set some basic LiDAR readings
                # Simulate walls at grid boundaries
                if x <= -self.grid_size[0] + 1:
                    mock_state[5:8] = 0.2  # Left side LiDAR readings show closer obstacles
                if x >= self.grid_size[0] - 1:
                    mock_state[13:16] = 0.2  # Right side LiDAR readings show closer obstacles
                if y <= -self.grid_size[1] + 1:
                    mock_state[1:4] = 0.2  # Front LiDAR readings show closer obstacles
                if y >= self.grid_size[1] - 1:
                    mock_state[9:12] = 0.2  # Back LiDAR readings show closer obstacles
                
                # Get action using the network
                try:
                    with torch.no_grad():
                        mock_state_tensor = torch.FloatTensor(mock_state).to(device)
                        q_values = self.q_network(mock_state_tensor)
                        action = torch.argmax(q_values, dim=1).item()
                    row += action_symbols[action] + "|"
                except Exception as e:
                    print(f"Error getting policy action: {e}")
                    row += "?|"  # Fallback symbol if error
            print(row)
            print("-" * (self.grid_size[0] * 2 + 1))